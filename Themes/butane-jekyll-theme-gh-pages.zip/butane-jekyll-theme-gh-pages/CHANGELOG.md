# Release Notes

## [1.0.0] - 2015-11-29
### Released
- Initial release.
